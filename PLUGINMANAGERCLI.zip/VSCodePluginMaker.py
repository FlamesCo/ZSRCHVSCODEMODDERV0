#!/usr/bin/env python3

import os
import sys
import argparse

from shutil import copyfile

def create_zsh_plugin(name, path):
    """Creates a new zsh plugin."""

    # Path to template file.
    template_path = os.path.join(os.path.dirname(__file__), "template.zsh")
    # Path to new plugin.
    plugin_path = os.path.join(path, name + ".zsh")
    ## if the plugin does not exist exit the program
    if not os.path.exists(plugin_path):
        copyfile(template_path, plugin_path)
        print("Created plugin: " + plugin_path)

    # Destination path for new plugin.
    plugin_path = os.path.join(path, name + ".py")

    # Copy template to destination.
    copyfile(template_path, plugin_path)

    print("Created new zsh plugin: {}".format(plugin_path))
  